<?php

namespace App\Http\Controllers;

use App\Production;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $line = $request->get('line');

        $query = Production::query();

        if (!empty($line)) {
            $query->where('product_line', $line);
        }

        $productions = $query
            ->orderBy('production_date')
            ->get();

        $lines = Production::select('product_line')
            ->distinct()
            ->orderBy('product_line')
            ->pluck('product_line');

        return view('dashboard', compact(
            'productions',
            'lines',
            'line'
        ));
    }
}