<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductionSeeder extends Seeder
{
    public function run()
    {
        DB::table('productions')->truncate();

        $lines = [
            'Geladeira',
            'Máquina de Lavar',
            'TV',
            'Ar-Condicionado'
        ];

        for ($day = 1; $day <= 31; $day++) {

            foreach ($lines as $line) {

                $produced = rand(850, 1200);
                $defects = rand(5, 40);

                DB::table('productions')->insert([
                    'production_date' => sprintf('2026-01-%02d', $day),
                    'product_line' => $line,
                    'produced_quantity' => $produced,
                    'defect_quantity' => $defects,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);

            }
        }
    }
}