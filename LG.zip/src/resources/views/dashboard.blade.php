<!doctype html>
<html lang="pt-br">

<head>

<meta charset="utf-8">

<title>LG Dashboard</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css"
rel="stylesheet">

</head>

<body>

<div class="container mt-5">

<h2 class="mb-4">

Eficiência da Produção - Planta A

</h2>

<form method="GET">

<div class="row mb-4">

<div class="col-md-4">

<select
name="line"
class="form-select"
onchange="this.form.submit()">

<option value="">

Todas as linhas

</option>

@foreach($lines as $item)

<option
value="{{ $item }}"
{{ $line == $item ? 'selected' : '' }}>

{{ $item }}

</option>

@endforeach

</select>

</div>

</div>

</form>

<table class="table table-striped table-bordered">

<thead class="table-dark">

<tr>

<th>Data</th>

<th>Linha</th>

<th>Produzidas</th>

<th>Defeitos</th>

<th>Eficiência (%)</th>

</tr>

</thead>

<tbody>

@foreach($productions as $production)

<tr>

<td>

{{ $production->production_date->format('d/m/Y') }}

</td>

<td>

{{ $production->product_line }}

</td>

<td>

{{ number_format($production->produced_quantity,0,',','.') }}

</td>

<td>

{{ number_format($production->defect_quantity,0,',','.') }}

</td>

<td>

{{ number_format($production->efficiency,2,',','.') }}

%

</td>

</tr>

@endforeach

</tbody>

</table>

</div>

</body>

</html>