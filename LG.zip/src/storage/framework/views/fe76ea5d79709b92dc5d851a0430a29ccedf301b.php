<!doctype html>
<html lang="pt-br">

<head>

<meta charset="utf-8">

<title>LG Dashboard</title>

<link
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css"
rel="stylesheet">

</head>

<body>

<div class="container mt-5">

<h2 class="mb-4">

Eficiência da Produção - Planta A

</h2>

<form method="GET">

<div class="row mb-4">

<div class="col-md-4">

<select
name="line"
class="form-select"
onchange="this.form.submit()">

<option value="">

Todas as linhas

</option>

<?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<option
value="<?php echo e($item); ?>"
<?php echo e($line == $item ? 'selected' : ''); ?>>

<?php echo e($item); ?>


</option>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</select>

</div>

</div>

</form>

<table class="table table-striped table-bordered">

<thead class="table-dark">

<tr>

<th>Data</th>

<th>Linha</th>

<th>Produzidas</th>

<th>Defeitos</th>

<th>Eficiência (%)</th>

</tr>

</thead>

<tbody>

<?php $__currentLoopData = $productions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $production): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>

<td>

<?php echo e($production->production_date->format('d/m/Y')); ?>


</td>

<td>

<?php echo e($production->product_line); ?>


</td>

<td>

<?php echo e(number_format($production->produced_quantity,0,',','.')); ?>


</td>

<td>

<?php echo e(number_format($production->defect_quantity,0,',','.')); ?>


</td>

<td>

<?php echo e(number_format($production->efficiency,2,',','.')); ?>


%

</td>

</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tbody>

</table>

</div>

</body>

</html><?php /**PATH /var/www/resources/views/dashboard.blade.php ENDPATH**/ ?>